"""Read-only historical intake; no reference decisions, models, or scoring."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib
import json
import shutil
import subprocess
import sys
import uuid

BASE = Path(__file__).resolve().parent
EVIDENCE = Path(r'C:\Users\86177\Desktop\work').resolve(strict=True)
CODE = Path(r'C:\Users\86177\.codex\worktrees\phase1-diagnostic-cases\work').resolve(strict=True)
PUB = Path(r'C:\Users\86177\.codex\worktrees\phase2a-publication\work').resolve(strict=True)
ROOT = BASE / ('phase2c_intake_20261003_' + uuid.uuid4().hex[:8])
assert not ROOT.is_relative_to(EVIDENCE) and not ROOT.is_relative_to(CODE)
sys.path.insert(0, str(CODE))
from scripts.artifact_io import sha256_json
from scripts.ts_strategy_engine.learning_evaluation import _load_bundle

def h(data):
    return hashlib.sha256(data).hexdigest()

def put(path, obj):
    with path.open('x', encoding='utf-8', newline='\n') as f:
        f.write(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args], env={**__import__('os').environ, 'GIT_OPTIONAL_LOCKS': '0'})

assert git(PUB, 'rev-parse', 'HEAD').decode().strip() == 'eccfaa274b7ac73e266420fa7a05be917a5b18c9'
assert not git(PUB, 'status', '--porcelain').strip()
assert git(CODE, 'rev-parse', 'HEAD').decode().strip() == 'b353ba4a00d0ee1d5b3f833dc71d0634f1a1e9cd'
assert not git(CODE, 'status', '--porcelain').strip()
old = BASE / 'phase2b_diagnostic_certainty_v1_20261003'
harness = old / 'harness/diagnostic_certainty_v1.txt'
assert h(harness.read_bytes()) == 'e45bbff5866ec94794be22fb36854b91a9ba5e78dbbb72f8b6259cde948630cc'
before = {str(p): h(p.read_bytes()) for p in [harness, old/'comparison_report.json', old/'control/first_raw_answer.txt']}
for name in ['learning_cases.py', 'learning_evaluation.py', 'learning_cli.py', 'learning_evidence.py', 'strategy_learning.py']:
    p = CODE / 'scripts/ts_strategy_engine' / name
    before[str(p)] = h(p.read_bytes())
p = CODE / 'configs/ts_strategy_engine/learning.yaml'
before[str(p)] = h(p.read_bytes())
prior = BASE / 'sbq_agent_eval/phase2a_20260930_215046_6b0645bc/revision_03_user_approved_20261001'
pubmanifest = json.loads((PUB/'reports/agent_eval_phase2a/phase2a_20260930_215046_6b0645bc/revision_03_user_approved_20261001/publication_manifest.json').read_bytes())
for item in pubmanifest['archive']['files']:
    p = prior / item['path']; data = p.read_bytes()
    assert h(data) == item['sha256']
    before[str(p)] = h(data)
dirty = git(EVIDENCE, 'status', '--porcelain')
ROOT.mkdir(exist_ok=False)
for name in ['snapshots', 'private', 'control', 'reviewer_packet']:
    (ROOT/name).mkdir()
ctx = {'created_at': datetime.now(timezone(timedelta(hours=8))).isoformat(), 'code_root': str(CODE), 'evidence_root': str(EVIDENCE), 'output_root': str(ROOT), 'observed_publication_head': git(PUB,'rev-parse','HEAD').decode().strip(), 'observed_code_head': git(CODE,'rev-parse','HEAD').decode().strip(), 'observed_evidence_head': git(EVIDENCE,'rev-parse','HEAD').decode().strip(), 'evidence_branch': git(EVIDENCE,'branch','--show-current').decode().strip(), 'existing_evidence_dirty_entries': len(dirty.splitlines()), 'existing_evidence_status_sha256': h(dirty), 'role': 'case_curator_not_reference_approver_or_answer_generator', 'reference_status': 'pending_independent_review', 'reference_approved': False, 'models_authorized_only_after_reviewed_bundle': True}
put(ROOT/'launch_context.json',ctx)
audit_cmd = [sys.executable, '-X', 'utf8', '-B', '-m', 'scripts.state_manager', '--root', str(PUB), 'audit', '--phase', 'start', '--format', 'json']
audit = subprocess.run(audit_cmd,cwd=PUB,capture_output=True)
(ROOT/'control/repository_audit.json').write_bytes(audit.stdout)
commands = [{'command':audit_cmd,'cwd':str(PUB),'exit_code':audit.returncode,'stderr':audit.stderr.decode(errors='replace')}]
sources = {}

def source(rel):
    path = (EVIDENCE/rel).resolve(strict=True)
    assert path.is_relative_to(EVIDENCE) and path.is_file() and path.stat().st_size < 1_000_000
    data = path.read_bytes()
    assert data == path.read_bytes(), 'Source changed during reading'
    before[str(path)] = h(data)
    if rel not in sources:
        dest = ROOT/'private/raw'/('s_' + h(rel.encode('utf-8'))[:12] + path.suffix)
        dest.parent.mkdir(parents=True,exist_ok=True)
        with dest.open('xb') as f:f.write(data)
        sources[rel]={'original_path':str(path),'sha256':h(data),'bytes':len(data),'copy':str(dest.relative_to(ROOT))}
    return data

def obj(rel):return json.loads(source(rel))

def text_column(rel, marker, column):
    data = source(rel)
    lines = data.decode('utf-8').splitlines()
    indices = [i for i,line in enumerate(lines) if marker in line]
    assert len(indices)==1
    i = indices[0]
    value = lines[i].split('|')[column].strip()
    return value, {'source':sources[rel], 'line_start':i+1,'line_end':i+1,'pipe_column_zero_based':column,'transform':'Exact column text, outer whitespace removed; no numeric reserialization of source.'}

def line_block(rel, start, end):
    lines = source(rel).decode('utf-8').splitlines()
    return '\n'.join(lines[start-1:end]), {'source':sources[rel], 'line_start':start,'line_end':end,'transform':'Exact selected source lines joined with LF; no inferred observations.'}

candidates=[]
cases=[]
eid=1

def add(cid,gid,event,reaction,task,question,values,provenance,limitations,include=True,review_priority=None):
    global eid
    snapshot = ROOT/'snapshots'/f'{cid}_observations.json'
    if include:
        put(snapshot,values)
        public=[]
        for key,value in values.items():
            assert not isinstance(value,(dict,list))
            public.append({'evidence_id':f'e{eid:03d}','path':str(snapshot),'sha256':h(snapshot.read_bytes()),'pointer':'/'+key,'value':value})
            eid+=1
        cases.append({'case_id':cid,'group_id':gid,'question':question,'provenance':'incomplete','public_evidence':public,'reference':None})
    else:public=[]
    candidates.append({'case_id':cid,'group_id':gid,'event_id':event,'reaction':reaction,'task_provenance':task,'draft_included':include,'question_proposal':question,'public_observations':values,'evidence_ids':[x['evidence_id'] for x in public],'provenance':provenance,'visibility':'partially_verified; observed times come from source text only, not file mtime; original historical reading extent not established','limitations':limitations,'review_priority':review_priority,'review_status':'pending','proposed_reference':None,'independent_review_completed':False,'reference_approval':None})

elog='docs/04_ERROR_LOG.md'
v,prov=text_column(elog,'`E-016`',2)
add('h001','g001','VASP9655434','CO* -> C*+O*','Nine-image launch job9655434; replacement9655921 is same event family, not a second independent case.','根据给定历史记录，诊断该启动阶段的故障及仍需核实的因果范围；不要将启动失败解释为科学路径失败。',{'material_kind':'historical_summary_not_original_stdout','record_excerpt':v},[prov],'Only mutable historical summary locally located; original9655434 stdout not located. Confirm any bounded label against this provenance before inclusion.',review_priority='Potential directly evidenced cause control; reviewer must decide, not curator.')

freq='calculations/fe110_ch_h_to_ch2_ts_20260810/frequency/vfa_local_ch_fe5_from_dimer9709074_20260814/vfa_analysis_diagnostic_frequency_only_20260816.json'
fo=obj(freq)
fkeys=['normal_completion','imaginary_frequency_count','meaningful_imaginary_frequency_min_cm1','additional_soft_mode_abs_max_cm1','frequency_threshold_status','dimer_technical_acceptance','dimer_frequency_handoff_acceptance','connectivity_required']
add('h002','g002','VFA9710404_diagnostic_classification_20260816','CH*+H* -> CH2*','Completed local-frequency diagnostic; only optional threshold-based frequency classification at this snapshot, not overall TS acceptance.','仅诊断此历史快照下阈值型频率分类无法给出结论的原因和下一步审核路由；不要据此判定整个计算或最终 TS 失败。',{k:fo[k] for k in fkeys},[{'source':sources[freq],'pointers':['/'+k for k in fkeys],'transform':'Exact scalar observations; later notes, reviewer and accepted/reference decisions not exported.'}],'Snapshot itself is a prior derived diagnostic analysis. Later accepted TS state is preserved in private provenance for scope checks, not exported into this earlier snapshot.',review_priority='Potential directly evidenced configuration-gap control; requires scope and label review.')
later='calculations/fe110_ch_h_to_ch2_ts_20260810/diagnostics/ts_validation_review_dimer9709074_mode24_20260816/validation_pipeline_status.json'
source(later)

geom='calculations/fe110_c_h_to_ch_ts_20260818/gpu_smoke_20260819/smoke_path_structure_review.json'
go=obj(geom)
manifest='calculations/fe110_c_h_to_ch_ts_20260818/gpu_smoke_20260819/returned_from_mz73/ml_neb_smoke/gpu_ml_neb_path_manifest.candidate.json'
mo=obj(manifest)
values={'total_images':len(go['images']),'internal_C_H_A':go['images'][1]['C_H_A'],'link_00_01_H_displacement_A':go['adjacent_links'][0]['H_mic_displacement_A'],'link_01_02_H_displacement_A':go['adjacent_links'][1]['H_mic_displacement_A'],'fixed_atom_max_displacement_A':go['adjacent_links'][0]['fixed_atom_max_mic_displacement_A'],'configured_max_steps':mo['run_settings']['ordinary_max_steps'],'optimizer_converged':mo['optimizer']['ordinary_ml_neb']['converged'],'completed_steps':mo['optimizer']['ordinary_ml_neb']['steps']}
add('h003','g003','GPU1190_path_resolution_review','C*+H* -> CH*','Three-image one-step smoke path; job1191 resolution rebuild is related follow-up and cannot be another independent held-out case.','只针对给定路径测量和规定的重要 C-H 区间 1.3–1.8 Å，诊断生产路径分辨率审核问题及其因果确定性；不要把本次刻意限制的一步预算单独当作优化器缺陷，也不作模型误差或最终 TS 判断。',values,[{'source':sources[geom],'pointers':['/images/1/C_H_A','/adjacent_links/0/H_mic_displacement_A','/adjacent_links/1/H_mic_displacement_A','/adjacent_links/0/fixed_atom_max_mic_displacement_A'],'transform':'Exact measured scalars from historical geometry review; explicit failure verdict and repair advice not selected.'},{'source':sources[manifest],'pointers':['/run_settings/ordinary_max_steps','/optimizer/ordinary_ml_neb/converged','/optimizer/ordinary_ml_neb/steps'],'transform':'Exact producer scalars.'}],'Important interval comes from historical review resolution_reason text; neutral question quotes only interval, not later resolution diagnosis. Verify sufficient context and whether this bounded question fits existing failure schema.')

prefix='calculations/fe110_c2ho_h_to_c2h2o_ts_20260822/h_migration_is_a_int06_path_20260926/gpu_execution_20260926/'
po=obj(prefix+'producer_exit_record.failure.1793.1703571.json')
for name in ['slurm-1793.out','scheduler_1793.txt','batch-env-probe-1794.out','user_authorization_retry1.md']:source(prefix+name)
add('h004','g004','GPU1793_wrapper_startup','C2HO*+H* -> C2H2O*; IS-A -> INT06 migration','GPU1793 and environment probe1794/retry1802 are one lineage, not independent cases.','审核完整本地材料是否足以诊断该包装器启动故障；不要仅用退出码设为未知。',{k:po[k] for k in ['status','exit_code','phase','finished_utc']},[{'source':sources[prefix+'producer_exit_record.failure.1793.1703571.json'],'pointers':['/status','/exit_code','/phase','/finished_utc']},{'source':sources[prefix+'user_authorization_retry1.md'],'role':'Later explicit TMPDIR attribution; must not suppress it to manufacture an unknown case.'}],'Excluded from draft public package: later attribution exists, original causal stderr not locally located. Whole local evidence requires independent adjudication; cannot fabricate an unknown or confirmed cause.',include=False)

v,prov=text_column(elog,'`E-019`',2)
add('h005','g004','DIMER9781734','C2HO*+H* -> C2H2O*; INT06 -> MID migration','Dimer9781734; SCF9789598 recovery belongs to same lineage and is not a second case.','针对该历史 Dimer 检查点，诊断应优先调查的失败类别、因果确定性和下一步；只评价给定记录，不作后续恢复或最终 TS 判断。',{'material_kind':'historical_summary_not_raw_residuals','record_excerpt':v},[prov],'Original checkpoint/OUTCAR residuals not locally located; summary reports nonconverged force evaluations but not a complete causal mechanism. Related to development reaction family, not reaction-held-out.')

v,prov=line_block('docs/02_CURRENT_STATE.md',305,311)
add('h006','g005','VASP9606916','CHO_formyl_Oend_top adsorption','O-end/top formyl adsorption job9606916; later structure/result promotion not evaluated.','仅根据历史检查点诊断该吸附弛豫停止后的收敛问题和下一步；不要判定后续任务结果、模型误差或把电子收敛与离子收敛混同。',{'material_kind':'historical_summary_not_original_OUTCAR','record_excerpt':v},[prov],'Original OUTCAR/force history not locally located; raw available status folder lacks this job. Preserve secondary-source limitation and do not confirm H-transfer mechanism from distances alone.')

v,prov=line_block('docs/02_CURRENT_STATE.md',129,133)
add('h007','g004','SCF9753825_dispatch','C2HO*+H* -> C2H2O*; migration electronic recovery; exact segment requires confirmation','SCF9753658/9753825 are one dispatch-retry family. Possible relation to other migration recovery families must be reviewed before claiming independence.','诊断记录中的任务启动/派发问题及仍未确定的根因范围；不能从历史 RUN 状态推出 VASP 已启动或 SCF 本身失败。',{'material_kind':'historical_checkpoint_summary','record_excerpt':v},[prov],'Original scheduler query and MPI probe files not locally located; exact lineage/segment needs reviewer confirmation. If same calculation as another selected case, merge or exclude before freeze.')

spec={'schema_version':1,'cases':cases}
put(ROOT/'snapshots/manifest.json',spec)
put(ROOT/'intake.json',{'status':'AWAITING_INDEPENDENT_REFERENCE_REVIEW','candidate_events':len(candidates),'draft_cases':len(cases),'approved_references':0,'scorable_cases':0,'group_count':len({c['group_id'] for c in candidates}),'candidates':candidates,'sources':sources,'source_missing':['archive/state_history/ERROR_LOG_through_20260627.md','original stdout/checkpoints for9655434,9781734,9753825,9606916 not located in targeted authorized directories'],'selection_protocol':'History indexes first, then targeted known reaction/task paths. No models, scores, harness content or expected harness behavior used to formulate references. No references formulated by curator.','holdout_scope':'Event-held-out candidates; reaction group g004 overlaps development family and must be separated from any reaction-held-out claim. No random splitting of associated samples.','status_coverage':{'confirmed':'not yet independently established; h001/h002 prioritized for evidence-based adjudication','hypothesis':'not yet independently established','unknown':'not yet independently established; h004 explicitly excluded rather than deleting later attribution'},'excluded_successful_events':['GPU735 H2-derived converged smoke','GPU736 CH3O converged smoke','GPU1319 successful speed benchmark','VASP9704031 successful pilot','GPU1274 passing local force screen; no fabricated failure'], 'benchmark_unchanged':True})

review_cases=[{k:c[k] for k in ['case_id','group_id','event_id','reaction','task_provenance','question_proposal','public_observations','evidence_ids','provenance','limitations','review_status']} for c in candidates]
put(ROOT/'reviewer_packet/candidates.json',{'role':'independent_reference_review_request','cases':review_cases,'reference_approved':False,'candidate_rule_provided':False,'development_answers_or_scores_provided':False})
review_readme='''# 新历史候选独立审核请求

请仅依历史材料、问题范围和既有标签/路由协议制定参考，不使用任何候选提示规则、开发答案或预期实验结果。该包不含实验 Harness 或开发评分。

每项请决定：纳入/暂缓/排除、公开观测是否充分及是否有事后结论泄漏、问题范围、真实来源时间边界、是否与另一计算属于同一重试链。然后给出现有格式 expected：failure_class、root_cause_status、next_review、逐项 evidence_ids，并说明依据及诊断范围。所有 reference 当前为空；请不要批准空参考。

h001/h002 有直接启动配置或缺失分级配置的记录，适合检查在限定问题范围内证据是否确实成立；由审核者决定确定程度。h004 只有包装器退出记录，但后来有 TMPDIR 归因，不能删去后者制造未知题。独立审核后再判断是否覆盖 confirmed/hypothesis/unknown，并确保至少两个真实 confirmed 案例；不足则保持不足。

源码策略允许路由见 policy_routes.json。evidence_ids 拟统一采用本题全部公开证据 ID，只检查输入覆盖，不评价证据筛选；请一并审核这一约定。题面仍为草稿，不在参考建立之前冻结。

历史原文件的真实路径、哈希及抽取定位见 candidates.json；../private/raw 保留许可范围内的原字节。这里的独立审核请求不等于已完成独立审核，也不冒充用户批准。
'''
with (ROOT/'reviewer_packet/README.md').open('x',encoding='utf-8',newline='\n') as f:f.write(review_readme)
from scripts.ts_strategy_engine.strategy_learning import policy
put(ROOT/'reviewer_packet/policy_routes.json',{'failure_routes':policy()['failure_routes'],'root_cause_status':['confirmed','hypothesis','unknown'],'reference_approval_status':'pending'})
queue=['# Phase 2C 新参考审核队列','', '状态：AWAITING_INDEPENDENT_REFERENCE_REVIEW。7个线索、6个可构建草稿、0个已批准参考。题面未冻结，A/B未运行。组织者没有填写 proposed_reference，也没有把 Harness 交给参考审核过程。','', '| ID | 分组/事件 | 来源及范围 | 具体审核问题 | 状态 |','|---|---|---|---|---|']
for c in candidates:
    queue.append(f"| {c['case_id']} | {c['group_id']} / {c['event_id']} | {c['reaction']}；见 intake.json 中逐来源哈希/指针/行号 | {c['limitations']}；请独立给出四字段 expected 或排除。 | pending |")
queue.extend(['','h004不在草稿包。g004关联原开发反应，且h007谱系未确认，不能将其计为独立反应泛化证据。至少两个confirmed、三类参考状态覆盖及所有科学断言均等待独立审核，当前不能宣称达标。'])
with (ROOT/'REVIEW_QUEUE.md').open('x',encoding='utf-8',newline='\n') as f:f.write('\n'.join(queue)+'\n')
build_cmd=[sys.executable,'-X','utf8','-B','-m','scripts.ts_strategy_engine.cli','learning','cases-build','--manifest',str(ROOT/'snapshots/manifest.json'),'--allowed-root',str(ROOT/'snapshots'),'--bundle',str(ROOT/'draft_bundle')]
build=subprocess.run(build_cmd,cwd=CODE,capture_output=True)
(ROOT/'control/build_stdout.txt').write_bytes(build.stdout)
(ROOT/'control/build_stderr.txt').write_bytes(build.stderr)
commands.append({'command':build_cmd,'cwd':str(CODE),'exit_code':build.returncode})
assert build.returncode==0,build.stderr.decode()
marker,public,private=_load_bundle(ROOT/'draft_bundle')
assert all(c['reference'] is None and c['provenance']=='incomplete' for c in private['cases'])
assert len(public['cases'])==6
assert sha256_json(public)==marker['public_sha256']
assert marker['public_sha256']!='500d33ac92a838371e1f76e096e6bc0db95ec8d864c0993495a2467a191d9ba2'
for path,identity in before.items():assert h(Path(path).read_bytes())==identity,path
assert not git(PUB,'status','--porcelain').strip() and not git(CODE,'status','--porcelain').strip()
dirty_after=git(EVIDENCE,'status','--porcelain')
check={'draft_cases':6,'references_null':True,'approved_references':0,'scorable_cases':0,'draft_public_sha256':marker['public_sha256'],'public_question_frozen':False,'loader_passed':True,'source_hashes_verified_unchanged':len(before),'harness_identity_verified_unchanged':True,'development_inputs_verified_unchanged':28,'evidence_git_status_unchanged':dirty==dirty_after,'evidence_dirty_entries_after':len(dirty_after.splitlines()),'code_publication_worktrees_clean':True,'independent_reference_review_completed':False,'status_coverage_confirmed':False,'at_least_two_correct_confirmed_established':False,'A_answer_tasks':0,'B_answer_tasks':0,'scorer_runs':0,'no_commit_push_merge_sync':True}
put(ROOT/'artifact_checks.json',check)
put(ROOT/'control/commands.json',commands)
put(ROOT/'control/previous_preparation_failure.json',json.loads((BASE/'phase2c_intake_20261003_ee3a029b/control/preparation_failure.json').read_bytes()))
put(ROOT/'control/immutable_files.json',before)
protocol={'status':'NOT_STARTED_PENDING_REVIEW','A':'baseline public task input only','B':'same input preceded only by frozen diagnostic_certainty_v1','order':'Run A once, preserve/freeze original response and events, then B once. Do not score either condition until both original outputs are frozen. No answer repair or regeneration.','required_same_settings':['CLI executable hash/version immediately before A and B','model setting','reasoning effort','service tier','disabled features and invocation config','public input bytes and canonical identity','FORMAT and extraction rule'],'reference_before_question_freeze':True,'reference_required_before_execution':True,'minimum_confirmed_controls':2,'requested_reference_statuses':['confirmed','hypothesis','unknown'],'metric_definitions':{'overall':'exact full-answer matches / all scored cases; missing/invalid answers kept in total','by_reference_status':'exact matches / all cases in each reference root_cause_status stratum','false_confirmed':'valid answer status confirmed when approved reference status hypothesis or unknown','false_uncertain':'valid answer status hypothesis or unknown when approved reference confirmed','invalid_or_missing':'report separately; never omit from overall denominator'},'classification_order':['MIXED when any gained correct cases and any old-correct regressions','REGRESSION for any old-correct regression or independently reviewed systematic confirmed downgrade without gains','PROMOTION_CANDIDATE requires added correct cases, no old-correct regression, false_confirmed reduced, and no observed new false_uncertain on confirmed controls','NO_CHANGE for no added correct cases and no regression'],'adjudication_limit':'Systematic confirmed downgrading is not assigned an invented threshold; give all per-case errors and defer any ambiguity to review. Label candidate effects limited to this held-out set. No production promotion.'}
put(ROOT/'ab_protocol_pending_review.json',protocol)
report=f'''# Phase 2C 历史候选准备

当前状态：**AWAITING_INDEPENDENT_REFERENCE_REVIEW**。已整理7个不同事件线索、5个分组，构建6题 incomplete 草稿；已批准参考和可评分案例均为0。未执行A/B或评分，题面尚未冻结。

## 完成的工作

固定开发结果6971531、候选eccfaa2和Harness字节身份；未修改原五题、参考、policy、scorer或Harness。核实历史根目录为{EVIDENCE}，源码根目录为{CODE}；源码与发布工作树干净。历史工作树原有{len(dirty.splitlines())}条状态记录保持原样。

材料沿现有错误记录、状态索引和明确的反应/任务目录只读查找。发现索引指向archive/state_history/ERROR_LOG_through_20260627.md不存在，记录缺口，未补文件或扫描整盘。成功计算没有强行改为失败；同一计算的重试只作为谱系材料，不扩成独立案例。

候选详见[intake.json](intake.json)、[审核队列](REVIEW_QUEUE.md)及[不含Harness/开发答案的审核请求](reviewer_packet/README.md)。h001为历史并行启动配置失败；h002为当时可选频率分类配置缺口；h003为C-H路径分辨率观测；h004包装器故障因存在后续TMPDIR归因且缺少原始因果日志而暂不入草稿；h005为不同Dimer事件的SCF症状；h006为formyl吸附弛豫检查点；h007为不同SCF派发事件、但谱系仍须确认。

## 来源及独立性限制

g004与开发集属于同一大反应家族，不能计作反应完全留出；h007与其他迁移恢复的关系还待确认，不能宣称所有候选统计独立。h001/h005/h006/h007只有历史摘要而缺少本地原始故障文件，保留partially_verified，独立审核可要求补证或排除。h002/h003为原有诊断分析中的观测字段，原始/派生身份如实标注。晚于所选快照的接受结论用于私有范围核对，未作为早期公开题面的证据。

参考由待指定的独立审核者依证据制定，组织者未填写任何expected、root_cause_status提案或approved。h001/h002可供审核者核验直接原因反例；目前尚不能宣称至少两个confirmed确实正确，也未建立confirmed/hypothesis/unknown三类覆盖。h004不能删除既有归因材料来凑unknown。缺少的状态覆盖如实保持缺口。

## 已执行核验

现有cases-build退出码{build.returncode}，6题草稿来源/类型/身份通过现有loader；未运行cases-evaluate，未创建answers。草稿public_sha256为{marker['public_sha256']}，不与原开发集身份混用。旧28份批准版本材料、Harness和已读源码/历史材料共{len(before)}份核验未变。[产物核验](artifact_checks.json)、[实际命令与退出码](control/commands.json)。只读repo-state audit退出码{audit.returncode}，输出保留；未修复投影或运行sync。

这里的draft_bundle仅证明既有构建/加载接口可用，参考为null且provenance=incomplete；它不是冻结的held-out评测包，不能交给模型答题。关键词及结构检查不构成公开题面的语义无泄漏证明，独立审核仍须确认。

## 下一步审核材料

请独立审核上述真实观测、范围与谱系，逐项给出现有四字段参考、完整evidence_ids和可核验批准来源；必要时排除或补证。审核完成后才新建review.json/reviewed_bundle并冻结公开三文件。随后按[待审核A/B执行与度量约定](ab_protocol_pending_review.json)，在相同当前CLI软件环境中先A后B各一次；按总分、参考确定性分层、false_confirmed/false_uncertain报告。当前没有泛化结论或晋级结果。

未修改生产源码、AGENTS、科学阈值、execution gate、数据库或模型权重；未访问生产数据库、运行SSH/HPC/VASP/Sella/训练、sync、commit/push/merge。新输出只在独立output_root。
'''
with (ROOT/'report.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
shutil.copyfile(Path(__file__),ROOT/'control/prepare_intake.py')
manifest={p.relative_to(ROOT).as_posix():{'bytes':p.stat().st_size,'sha256':h(p.read_bytes())} for p in ROOT.rglob('*') if p.is_file()}
put(ROOT/'file_manifest.json',{'files':manifest})
print(json.dumps({'output_root':str(ROOT),'candidate_events':7,'draft_cases':6,'approved_references':0,'scorable_cases':0,'draft_public_sha256':marker['public_sha256'],'audit_exit_code':audit.returncode,'build_exit_code':build.returncode,'A_runs':0,'B_runs':0,'scorer_runs':0,'status':'AWAITING_INDEPENDENT_REFERENCE_REVIEW'},ensure_ascii=False))
