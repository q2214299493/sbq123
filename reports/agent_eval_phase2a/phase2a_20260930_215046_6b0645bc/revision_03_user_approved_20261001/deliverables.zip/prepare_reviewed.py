"""One-off, artifact-only preparation using the existing builder and loader."""
import copy
from datetime import datetime, timezone, timedelta
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile

REV = Path(__file__).resolve().parent
BASE = REV.parent
CODE = Path(r'C:\Users\86177\.codex\worktrees\phase1-diagnostic-cases\work')
PUB = Path(r'C:\Users\86177\.codex\worktrees\phase2a-publication\work')
EVIDENCE = Path(r'C:\Users\86177\Desktop\work')
OLD_HASH = '46effdb86474a049ba273155e30d7eb430bb889cfee851e0286eff796da51afd'
COMMIT = 'f5690e2bfe8eef71df96faf3ba59ad4a5165143e'
CODE_HEAD = 'b353ba4a00d0ee1d5b3f833dc71d0634f1a1e9cd'
NOW = datetime.now(timezone(timedelta(hours=8))).isoformat()
ENV = {**os.environ, 'GIT_OPTIONAL_LOCKS': '0', 'PYTHONIOENCODING': 'utf-8'}
COMMANDS = []


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as out:
        out.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def copy_bytes(source, target):
    with target.open('xb') as out:
        out.write(source.read_bytes())
    assert digest(source) == digest(target)


def run(args, cwd, *, allowed_codes=(0,)):
    result = subprocess.run(args, cwd=cwd, env=ENV, capture_output=True)
    COMMANDS.append({'argv': [str(x) for x in args], 'cwd': str(cwd),
                     'exit_code': result.returncode,
                     'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
                     'stderr': result.stderr.decode('utf-8', errors='replace')[:4000]})
    assert result.returncode in allowed_codes, COMMANDS[-1]
    return result


def git_state(root):
    head = run(['git', 'rev-parse', 'HEAD'], root).stdout.decode().strip()
    branch = run(['git', 'branch', '--show-current'], root).stdout.decode().strip()
    status = run(['git', 'status', '--porcelain=v1', '-z'], root).stdout
    return {'head': head, 'branch': branch,
            'status_records': len([x for x in status.split(b'\0') if x]),
            'status_sha256': hashlib.sha256(status).hexdigest()}


# Freeze and verify the permitted roots and historical publication before writing bundles.
assert REV.resolve() == REV and REV.is_relative_to(Path(
    r'C:\Users\86177\.codex\visualizations\2026\09\29\01a0eb4e-842b-7f33-9d59-87ee752f88e9'))
assert all(root.is_dir() and root.resolve() == root for root in (CODE, PUB, EVIDENCE))
before_git = {str(root): git_state(root) for root in (CODE, PUB, EVIDENCE)}
assert before_git[str(CODE)]['head'] == CODE_HEAD
assert before_git[str(PUB)]['head'] == COMMIT
assert before_git[str(CODE)]['status_records'] == before_git[str(PUB)]['status_records'] == 0
relative_zip = 'reports/agent_eval_phase2a/' + BASE.name + '/deliverables.zip'
published_bytes = run(['git', 'show', COMMIT + ':' + relative_zip], PUB).stdout
assert published_bytes == (PUB / relative_zip).read_bytes()
old_file_hashes = {}
with zipfile.ZipFile(PUB / relative_zip) as archive:
    assert archive.testzip() is None
    for name in archive.namelist():
        path = BASE / name
        assert archive.read(name) == path.read_bytes(), name
        old_file_hashes[name] = digest(path)
assert len(old_file_hashes) == 36
sys.path.insert(0, str(CODE))
from scripts.artifact_io import sha256_json, sha256_file
from scripts.ts_strategy_engine.learning_evaluation import _load_bundle
from scripts.ts_strategy_engine import learning_cases, learning_evaluation

old_marker, old_public, old_private = _load_bundle(BASE / 'revision_02/draft_bundle')
assert old_marker['public_sha256'] == sha256_json(old_public) == OLD_HASH
intake = read(BASE / 'revision_02/intake.json')
spec = read(BASE / 'snapshots/manifest_v2.json')
original_hashes = {}
for source in intake['sources']:
    path = Path(source['original_path'])
    assert path.is_relative_to(EVIDENCE) and path.is_file()
    assert digest(path) == source['original_sha256'], str(path)
    original_hashes[str(path)] = digest(path)
assert len(original_hashes) == 6
code_files = ['scripts/ts_strategy_engine/learning_cases.py',
              'scripts/ts_strategy_engine/learning_evaluation.py',
              'scripts/ts_strategy_engine/learning_cli.py', 'scripts/artifact_io.py',
              'configs/ts_strategy_engine/learning.yaml']
code_hashes = {name: digest(CODE / name) for name in code_files}
write(REV / 'startup_observations.json', {
    'recorded_at': NOW, 'actual_shell_cwd': str(Path.cwd()),
    'new_write_root': str(REV), 'git': before_git,
    'approved_base_public_sha256': OLD_HASH,
    'commit_zip_sha256': hashlib.sha256(published_bytes).hexdigest(),
    'verified_zip_members': old_file_hashes, 'original_sources': original_hashes,
    'code_files': code_hashes, 'builder_module': learning_cases.__file__,
    'loader_module': learning_evaluation.__file__})
audit = run([sys.executable, '-X', 'utf8', '-B', '-m', 'scripts.state_manager',
             '--root', str(CODE), 'audit', '--phase', 'start', '--format', 'json'],
            CODE, allowed_codes=(0, 1))
with (REV / 'repository_audit.json').open('xb') as out:
    out.write(audit.stdout)
audit_json = read(REV / 'repository_audit.json')

# No independent expert identity or original message metadata is invented.
copy_bytes(Path(r'D:\Review_Phase2A_f5690e2.md'), REV / 'review_attachment.md')
approval_hash = digest(REV / 'user_approval.txt')
source_description = {
    'kind': 'current_user_message_transcription',
    'reviewer': '本次用户批准', 'independent_expert_review': False,
    'original_message_id': None, 'original_message_timestamp': None,
    'recorded_at': NOW, 'recorded_at_role': 'local artifact creation time, not historical approval time',
    'path': 'user_approval.txt', 'byte_sha256': approval_hash,
    'representation': 'Complete visible user-message text transcribed as UTF-8 with LF and a final newline; not a platform raw-message export.',
    'authority': 'The current human user explicitly approved the five bounded snapshot references and the all-evidence citation contract.',
    'review_attachment_byte_sha256': digest(REV / 'review_attachment.md')}
write(REV / 'approval_source.json', source_description)
limits = [
    'Historical observation times and the complete contemporaneous visibility/access scope remain partially_verified.',
    'Approval is for bounded offline snapshot diagnosis only, not scientific acceptance, model validity or execution authority.',
    'Five public development/regression cases share one reaction group; they are not a confidential held-out set or five independent reactions.',
    'The current conversation has seen references and cannot answer as a blind participant.',
    '隔离尚未验证']
scopes = {
    'c001': '只确认日志直接报告脚本权限错误；不确认缺少执行位、属主问题、挂载策略或其他具体底层原因。',
    'c002': '确认记录中的路径保护触发，原因保持假设；不得据此确认势函数误差。',
    'c003': 'confirmed 只针对题目限定的停止条件：三步预算已用尽，优化目标尚未达到。不代表 Sella 有缺陷、势函数不准确、整体试运行失败，也不保证增加步数必然收敛。',
    'c004': '给定检查点支持优先审查 SCF，但没有足够残差证据确认根因。不能把历史 RUN 状态或缺少结束标记解释成整个任务已经失败。',
    'c005': '只确认当时阶段的覆盖保护未通过。不能判定模型误差，不能将历史保护值推广为统一科学标准。'}
labels = {
    'c001': ('runtime', 'confirmed', 'repair_runtime_without_training', 1, 3),
    'c002': ('geometry', 'hypothesis', 'review_path_repair_without_assuming_model_error', 4, 12),
    'c003': ('optimizer', 'confirmed', 'diagnose_optimizer_and_path', 13, 20),
    'c004': ('scf', 'hypothesis', 'incar_custodian_diagnosis', 21, 32),
    'c005': ('geometry', 'hypothesis', 'review_path_repair_without_assuming_model_error', 33, 47)}
review_cases = {}
new_spec = copy.deepcopy(spec)
new_public = copy.deepcopy(old_public)
assert [c['case_id'] for c in spec['cases']] == list(labels)
assert all(c['provenance'] == 'incomplete' and c['reference'] is None for c in spec['cases'])
for case, public, candidate in zip(new_spec['cases'], new_public['cases'], intake['candidates']):
    cid = case['case_id']
    assert cid == public['case_id'] == candidate['case_id']
    failure, status, route, low, high = labels[cid]
    expected = {'failure_class': failure, 'root_cause_status': status,
                'next_review': route, 'evidence_ids': [f'e{i:03}' for i in range(low, high + 1)]}
    assert sha256_json(expected) == sha256_json(candidate['proposed_reference'])
    assert expected['evidence_ids'] == [e['evidence_id'] for e in public['evidence']]
    assert 'partially_verified' in candidate['visibility']
    if cid == 'c003':
        public['question'] = case['question'] = (
            '这次 Sella 试用有显式三步预算；力单位为 eV/A。本题只诊断给定三步预算结束时优化目标尚未达到这一停止条件，选择诊断分类、确定程度和审查路线。'
            'confirmed 如被选择，只表示该限定停止条件有直接证据，不表示 Sella 有缺陷、势函数不准确或整体试运行失败，也不保证增加步数必然收敛。')
    public['input_sha256'] = sha256_json({k: v for k, v in public.items() if k != 'input_sha256'})
    review_cases[cid] = {'review_status': 'approved', 'reviewer': '本次用户批准',
        'diagnosis': expected, 'approved_scope': scopes[cid],
        'visibility': candidate['visibility'], 'historical_visibility_status': 'partially_verified',
        'old_input_sha256': next(c['input_sha256'] for c in old_public['cases'] if c['case_id'] == cid),
        'new_input_sha256': public['input_sha256'], 'public_evidence_sha256': sha256_json(public['evidence'])}
new_hash = sha256_json(new_public)
review = {'schema_version': 1, 'reviewer': '本次用户批准',
          'approval_source': source_description, 'approval_scope': '给定快照下的离线诊断参考',
          'approved_original_commit': COMMIT, 'approved_original_revision': 'revision_02',
          'approved_original_public_sha256': OLD_HASH, 'new_public_sha256': new_hash,
          'limitations': limits, 'cases': review_cases}
sources_dir = REV / 'sources'
sources_dir.mkdir()
for name in ['c001_s01.json', 'c001_s01.txt', 'c002_s01.json', 'c003_s01.json',
             'c003_s02.json', 'c004_s01.json', 'c005_s01.json']:
    copy_bytes(BASE / 'snapshots' / name, sources_dir / name)
write(REV / 'review.json', review)
review_hash = digest(REV / 'review.json')
for case in new_spec['cases']:
    cid = case['case_id']
    for evidence in case['public_evidence']:
        evidence['path'] = 'sources/' + Path(evidence['path']).name
    case['provenance'] = 'reviewed_real'
    case['reference'] = {
        'review_status': 'approved',
        'review_basis': '本次用户批准；原文 user_approval.txt byte SHA-256=' + approval_hash
            + '；原对象 public SHA-256=' + OLD_HASH + '；' + scopes[cid]
            + ' Historical visibility remains partially_verified; this is not independent expert review.',
        'source': {'path': 'review.json', 'sha256': review_hash,
                   'pointer': '/cases/' + cid + '/diagnosis', 'value': review_cases[cid]['diagnosis']},
        'expected': review_cases[cid]['diagnosis']}
write(REV / 'cases_manifest.json', new_spec)
build = run([sys.executable, '-X', 'utf8', '-B', '-m', 'scripts.ts_strategy_engine.cli',
             'learning', 'cases-build', '--manifest', str(REV / 'cases_manifest.json'),
             '--allowed-root', str(REV), '--bundle', str(REV / 'reviewed_bundle')], CODE)
write(REV / 'build_receipt.json', json.loads(build.stdout.decode('utf-8')))
marker, built_public, private = _load_bundle(REV / 'reviewed_bundle')
assert sha256_json(built_public) == new_hash == marker['public_sha256']
assert sha256_json(built_public) == sha256_json(new_public)
assert len(private['cases']) == 5 and all(c['provenance'] == 'reviewed_real' for c in private['cases'])
assert sum(len(c['evidence']) for c in built_public['cases']) == 47
for current, old, secret in zip(built_public['cases'], old_public['cases'], private['cases']):
    cid = current['case_id']
    assert sha256_json(current['evidence']) == sha256_json(old['evidence'])
    assert current['group_id'] == old['group_id'] == 'g001'
    if cid != 'c003':
        assert sha256_json(current) == sha256_json(old)
    assert set(current) == {'case_id', 'group_id', 'question', 'evidence', 'input_sha256'}
    assert secret['reference']['source']['sha256'] == review_hash
    assert sha256_json(secret['reference']['expected']) == sha256_json(review_cases[cid]['diagnosis'])
    assert secret['reference']['expected']['evidence_ids'] == [e['evidence_id'] for e in current['evidence']]
pack = REV / 'answer_pack'
pack.mkdir()
copy_bytes(REV / 'reviewed_bundle/public.json', pack / 'public.json')
copy_bytes(BASE / 'revision_02/answer_pack/FORMAT.json', pack / 'FORMAT.json')
task = '''# 公开开发/回归案例：独立答题说明

仅依据本目录 public.json 的给定快照证据作答；FORMAT.json 列出完整的合法分类、确定程度与对应路线。next_review 必须与所选 failure_class 对应。所有证据保留原生 JSON 类型和值。

evidence_ids 必须列出本题全部公开证据 ID；
本轮该字段仅用于输入覆盖检查，
不评价证据筛选能力或因果相关性。

JSON 中逐项列出 ID，不使用范围字符串，不遗漏、重复或引用别题 ID；顺序不影响现有评分器的集合比较。

诊断范围仅为给定快照，不是科学接受或计算执行授权。confirmed 只确认题目限定、证据直接支持的事实，不自动确认底层原因。尤其 c003 只评估三步预算结束时目标尚未达到这一停止条件，不评价 Sella 缺陷、势函数准确性、整体试运行是否失败，也不保证增加步数收敛。运行状态与缺少结束标记不能直接证明整个任务失败；历史阶段保护值不是统一科学标准。原始历史观察时间和当时完整可见范围仍为 partially_verified。

五题均属于已公开的开发/回归材料，共享一个反应组，不是保密留出集或五个独立反应。当前准备会话已看过参考，不得充当盲测答题者。独立答题者应仅获得本公开包；目录分离不是访问控制。隔离尚未验证。不得读取其他目录的 review、private、审核队列、发布 ZIP、仓库参考或当前会话内容。

后续独立答题文件应包含 schema_version: 1、public_sha256 和 answers 数组；每题字段为 case_id、input_sha256、failure_class、root_cause_status、next_review、evidence_ids。复制 public.json 中的 input_sha256，不改写输入。本次准备未生成答案、未运行模型或评分。

public_sha256: HASH
'''.replace('HASH', new_hash)
with (pack / 'TASK.md').open('x', encoding='utf-8', newline='\n') as out:
    out.write(task)
assert {p.name for p in pack.iterdir()} == {'public.json', 'TASK.md', 'FORMAT.json'}
assert (pack / 'public.json').read_bytes() == (REV / 'reviewed_bundle/public.json').read_bytes()
# Public JSON is an allowlisted projection of the approved original evidence;
# no reviewer, reference, source paths or per-case answer mapping is added.
assert all(set(e) == {'evidence_id', 'pointer', 'value', 'source_sha256'}
           for c in built_public['cases'] for e in c['evidence'])
assert all(' / '.join(labels[cid][:2]) not in task for cid in labels)
after_git = {str(root): git_state(root) for root in (CODE, PUB, EVIDENCE)}
assert after_git == before_git
assert all(digest(BASE / name) == value for name, value in old_file_hashes.items())
assert all(digest(Path(name)) == value for name, value in original_hashes.items())
assert all(digest(CODE / name) == value for name, value in code_hashes.items())
assert not any(p.name.lower().startswith(('answers', 'score')) for p in REV.rglob('*'))
checks = {'status': 'READY_FOR_INDEPENDENT_ANSWER_WITH_ISOLATION_UNVERIFIED',
          'recorded_at': datetime.now(timezone(timedelta(hours=8))).isoformat(),
          'approved_original_public_sha256': OLD_HASH, 'public_sha256': new_hash,
          'private_sha256': marker['private_sha256'], 'approval_source_byte_sha256': approval_hash,
          'review_byte_sha256': review_hash, 'cases': 5, 'reference_available_cases': 5,
          'evidence_scalars': 47, 'groups': 1, 'paused_cases': [],
          'unchanged_old_files': 36, 'unchanged_original_sources': 6,
          'git_before': before_git, 'git_after': after_git,
          'artifact_checks': ['commit ZIP identity and all members', 'approved original canonical JSON identity',
             'native evidence identity unchanged', 'all five exact ID sets and user-approved references',
             'review source bindings', 'existing CLI build exit 0', 'existing loader accepted all five',
             'public projection allowlist and public pack contains only public/FORMAT/TASK',
             'c003 bounded question and private approval scope', 'old artifacts, original sources and Git unchanged'],
          'isolation_status': '隔离尚未验证', 'limitations': limits,
          'not_run': ['formal answers', 'model scoring', 'pytest/full repository suite',
                      'production calculations/training/database operations', 'repo-state sync', 'commit/push/merge']}
write(REV / 'artifact_checks.json', checks)
write(REV / 'execution_log.json', {'invocation': [sys.executable, '-X', 'utf8', '-B', str(Path(__file__))],
    'cwd': str(Path.cwd()), 'commands': COMMANDS,
    'loader': {'call': '_load_bundle(Path(revision_03/reviewed_bundle))', 'result': 'accepted'},
    'earlier_inspection_failure': {'exit_code': 1,
        'cause': 'A final read_text call omitted UTF-8 and used GBK; read-only inspection failed after successful ZIP and identity checks.',
        'resolution': 'Explicit UTF-8 decoding and python -X utf8; no write had occurred in the failing inspection.'}})
with (REV / 'report.md').open('x', encoding='utf-8', newline='\n') as out:
    out.write('# Phase 2A 用户批准版本\n\n'
        '已核对 f5690e2 的全部 36 个 ZIP 成员与本地产物字节一致；revision_02 规范 JSON 身份为 ' + OLD_HASH + '。\n\n'
        '本次用户批准原文、来源说明和字节 SHA-256 分别记录于 user_approval.txt、approval_source.json 和 review.json。审核者为“本次用户批准”，不是独立专家；平台消息 ID 和原始批准时间不可用，未编造。recorded_at 仅为本地记录生成时间。\n\n'
        '构建了 5 个 reviewed_real 参考、47 项未改动的公开标量、1 个反应组。reviewed_real 仅表示存在本次范围限定的真实用户批准；历史时间与全部可见范围仍为 partially_verified。c003 题面补充三步预算停止条件范围，其他四题输入不变；全部证据均与旧包规范 JSON 身份一致。\n\n'
        '新公开身份：' + new_hash + '。全部 ID 逐项记录在 JSON 中。TASK 明确全部引用只检查输入覆盖，不评价证据筛选或因果相关性。未修改评分器或生产代码。\n\n'
        '现有 cases-build CLI 退出码 0；现有 _load_bundle 接受全部 5 题。核验了参考源哈希、精确 ID 集合、公开字段白名单、独立公开包文件集合、c003 范围和旧文件/科学原件/Git 状态不变。详见 artifact_checks.json 与 execution_log.json。\n\n'
        '只读 repo-state audit 退出码 ' + str(audit.returncode) + '；完整结果保存在 repository_audit.json。审计漂移未修复，未运行 sync，不代表科学状态。首次只读检查末尾因默认 GBK 读取 UTF-8 文件退出 1；显式 UTF-8 后成功，无写入受到影响。\n\n'
        '未执行 pytest/Ruff 全仓测试（没有源码修改）；未生成正式 answers，未运行模型、评分、真实计算/训练、生产数据库操作、SSH、commit、push 或 merge。\n\n'
        '已准备好等待独立答题。隔离尚未验证。五题是已公开开发/回归材料，当前会话不能充当盲测答题者。不能声称保密留出集、独立反应泛化、科学接受或实测性能提升。\n\n'
        '下一步：验证独立答题者只可读取 answer_pack，再收集首次答案。\n')
write(REV / 'file_manifest.json', {'recorded_at': NOW,
    'files': {str(p.relative_to(REV)).replace('\\', '/'): {'byte_sha256': digest(p), 'bytes': p.stat().st_size}
              for p in sorted(REV.rglob('*')) if p.is_file()}})
print(json.dumps({'revision': str(REV), 'public_sha256': new_hash,
                  'cases': 5, 'reference_available_cases': 5, 'scoring_run': False,
                  'audit_exit_code': audit.returncode, 'isolation': '隔离尚未验证'}, ensure_ascii=False))
