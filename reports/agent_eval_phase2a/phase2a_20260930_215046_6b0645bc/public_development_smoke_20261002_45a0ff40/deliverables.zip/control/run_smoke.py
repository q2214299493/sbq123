"""One authorized Codex task; retain raw output without retries or answer repair."""
from datetime import datetime, timezone, timedelta
import hashlib
import json
import os
from pathlib import Path
import subprocess
import threading
import time

ROOT = Path(__file__).resolve().parent.parent
CONTROL = ROOT / 'control'
RUNTIME = ROOT / 'answer_runtime'
CLI = r'C:\Users\86177\AppData\Local\OpenAI\Codex\cli\codex.cmd'
MODEL = 'gpt-6.1-sol'
PUBLIC_HASH = '500d33ac92a838371e1f76e096e6bc0db95ec8d864c0993495a2467a191d9ba2'
NAMES = ['public.json', 'TASK.md', 'FORMAT.json']
DISABLED = ['shell_tool', 'unified_exec', 'apps', 'memories', 'multi_agent',
            'multi_agent_v2', 'plugins', 'remote_plugin', 'hooks', 'browser_use',
            'browser_use_external', 'computer_use', 'in_app_browser', 'view_image',
            'image_generation', 'code_mode', 'code_mode_host', 'skill_search',
            'workspace_dependencies', 'goals', 'unbounded_connection_retries']


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, obj):
    with path.open('x', encoding='utf-8', newline='\n') as out:
        json.dump(obj, out, ensure_ascii=False, indent=2)
        out.write('\n')


assert {p.name for p in RUNTIME.iterdir()} == set(NAMES)
public = json.loads((RUNTIME / 'public.json').read_text(encoding='utf-8'))
canonical = json.dumps(public, sort_keys=True, separators=(',', ':'))
assert hashlib.sha256(canonical.encode()).hexdigest() == PUBLIC_HASH
assert [c['case_id'] for c in public['cases']] == ['c001', 'c002', 'c003', 'c004', 'c005']
prompt = ('这是一次公开开发集受控试运行。以下三个文件是本次答题的全部任务材料。'
          '只根据给定内容一次性回答五题，输出 FORMAT.json 要求的完整回答 JSON，'
          '不要附加说明、检索、调用工具、执行命令、读取其他文件或修改文件。'
          '不要要求提供参考；不足的依据按题目规则处理。\n\n')
for name in NAMES:
    prompt += f'===== BEGIN {name} =====\n'
    prompt += (RUNTIME / name).read_text(encoding='utf-8')
    prompt += f'\n===== END {name} =====\n\n'
with (CONTROL / 'submitted_input.txt').open('x', encoding='utf-8', newline='\n') as out:
    out.write(prompt)
args = [CLI, '--no-daemon', '--ask-for-approval', 'never', 'exec',
        '--ignore-user-config', '--strict-config', '--ephemeral',
        '--sandbox', 'read-only', '--skip-git-repo-check', '--json', '--color', 'never',
        '--model', MODEL, '--cd', str(RUNTIME),
        '--output-last-message', str(CONTROL / 'first_raw_answer.txt')]
for feature in DISABLED:
    args.extend(['--disable', feature])
args.extend(['--enable', 'skip_host_skill_discovery'])
for key, value in {
    'web_search': 'disabled', 'project_doc_max_bytes': 0,
    'model_reasoning_effort': 'high', 'service_tier': 'default',
    'shell_environment_policy.inherit': 'none',
    'sqlite_home': str(CONTROL / 'cli_runtime_state'),
}.items():
    args.extend(['-c', key + '=' + json.dumps(value)])
args.append('-')
config = Path(r'C:\Users\86177\.codex\config.toml')
auth = Path(r'C:\Users\86177\.codex\auth.json')
start = datetime.now(timezone(timedelta(hours=8))).isoformat()
settings = {
    'evaluation_mode': 'public_development_smoke',
    'reference_access_isolation_verified': False,
    'capability_improvement_established': False,
    'public_sha256': PUBLIC_HASH, 'case_count': 5,
    'source_commit': '286ad0cbc4c4cbca455f018e26ff48fac170d646',
    'source_revision': 'revision_03_user_approved_20261001',
    'cli_version': 'codex-cli 0.159.0-alpha.12.1', 'requested_model': MODEL,
    'model_identifier_reported_by_backend': None,
    'argv': args, 'cwd': str(RUNTIME), 'started_at': start,
    'timeout_seconds': 300, 'task_attempt_count': 1,
    'underlying_model_request_count': 'unknown',
    'input_file_byte_sha256': {name: digest(RUNTIME / name) for name in NAMES},
    'submitted_input_byte_sha256': digest(CONTROL / 'submitted_input.txt'),
    'extraction_rule_before_execution': 'Accept an entire JSON response or one JSON code fence enclosing the entire response. Strip surrounding whitespace/fence only; no diagnosis, evidence-ID, identity, or missing-answer repair.',
    'user_config_sha256_before': digest(config), 'auth_file_sha256_before': digest(auth),
    'new_session': True, 'resume_used': False, 'fork_used': False,
    'audit_conversation_submitted': False, 'review_materials_submitted': False,
    'configuration_scope': 'Invocation only; no global config or enforced rule edits.',
    'tool_prevention_limit': 'Flags reduce access; complete reference isolation is not verified. Visible event audit does not prove absence of hidden context or hidden requests.'}
write(CONTROL / 'execution_settings.json', settings)
env = {**os.environ, 'GIT_OPTIONAL_LOCKS': '0', 'PYTHONIOENCODING': 'utf-8'}
event_types = {}
item_types = {}
lock = threading.Lock()


def drain(stream, target, parse_events=False):
    with target.open('xb') as out:
        for line in iter(stream.readline, b''):
            out.write(line)
            out.flush()
            if parse_events:
                try:
                    event = json.loads(line)
                except (ValueError, UnicodeError):
                    continue
                with lock:
                    kind = event.get('type', 'unknown')
                    event_types[kind] = event_types.get(kind, 0) + 1
                    item = event.get('item')
                    if isinstance(item, dict):
                        it = item.get('type', 'unknown')
                        item_types[it] = item_types.get(it, 0) + 1
    stream.close()


print(json.dumps({'stage': 'starting_single_task', 'model': MODEL,
                  'input_public_sha256': PUBLIC_HASH}), flush=True)
t0 = time.monotonic()
process = subprocess.Popen(args, cwd=RUNTIME, env=env, stdin=subprocess.PIPE,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE)
workers = [threading.Thread(target=drain, args=(process.stdout, CONTROL / 'first_events.jsonl', True)),
           threading.Thread(target=drain, args=(process.stderr, CONTROL / 'first_stderr.txt'))]
for worker in workers:
    worker.start()
process.stdin.write(prompt.encode('utf-8'))
process.stdin.close()
timed_out = False
last_progress = t0
while process.poll() is None:
    now = time.monotonic()
    if now - t0 >= 300:
        timed_out = True
        subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'],
                       capture_output=True)
        break
    if now - last_progress >= 20:
        with lock:
            snapshot = {'stage': 'running', 'elapsed_seconds': round(now - t0, 1),
                        'visible_event_types': dict(event_types), 'visible_item_types': dict(item_types)}
        print(json.dumps(snapshot), flush=True)
        last_progress = now
    time.sleep(0.25)
code = process.wait()
for worker in workers:
    worker.join()
elapsed = time.monotonic() - t0
receipt = {
    'evaluation_mode': 'public_development_smoke', 'exit_code': code,
    'timed_out': timed_out, 'elapsed_seconds': round(elapsed, 3),
    'task_attempt_count': 1, 'underlying_model_request_count': 'unknown',
    'visible_event_types': event_types, 'visible_item_types': item_types,
    'first_raw_answer_file_present': (CONTROL / 'first_raw_answer.txt').is_file(),
    'user_config_unchanged': digest(config) == settings['user_config_sha256_before'],
    'auth_file_content_unchanged': digest(auth) == settings['auth_file_sha256_before'],
    'public_input_files_unchanged': all(digest(RUNTIME / name) == settings['input_file_byte_sha256'][name]
                                        for name in NAMES),
    'stderr_byte_sha256': digest(CONTROL / 'first_stderr.txt'),
    'events_byte_sha256': digest(CONTROL / 'first_events.jsonl')}
write(CONTROL / 'execution_receipt.json', receipt)
print(json.dumps({'stage': 'single_task_finished', **receipt}, ensure_ascii=False), flush=True)
