# Phase 2A 复审记录：f5690e2

## 对象与结论

仓库：`q2214299493/sbq123`  
分支：`codex/phase2a-diagnostic-trial-20260930`  
提交：`f5690e2bfe8eef71df96faf3ba59ad4a5165143e`  
代码基线：`b353ba4a00d0ee1d5b3f833dc71d0634f1a1e9cd`

本次可以作为“真实诊断候选准备”交付，进入参考审核；不是已批准的正式基准、模型成绩或科学接受结论。本复审不构成批准参考、执行计算、发布材料或修改仓库的授权。

GitHub compare 返回：相对基线增加一个提交，只新增 Phase 2A 报告目录中的 README.md、REVIEW_QUEUE.md、publication_manifest.json、report.md、deliverables.zip 五个文件，未修改已跟踪的生产代码。GitHub Actions run 36733529458 的 conclusion 为 success。本环境未重新运行项目 pytest。

## 实际独立核验

普通二进制下载路径不可用。本轮通过 GitHub 连接读取 ZIP 的部分 Base64 行，解析完整 ZIP 本地文件记录；对抽取出的完整成员校验 CRC，并与公开发布清单的 SHA-256 比对。未执行归档内的整理脚本。

核验了十个完整成员：revision_02 的 public.json、private.json、TASK.md，以及七个快照成员（六份所附原始来源表示和 c001 派生 JSON）。十份文件均与发布清单的字节哈希一致。这不等于验证全部36份归档成员或整个ZIP的SHA-256。

核验结果：

- 5个案例、1个组g001、47项公开标量，逐题为3、9、8、12、15项。
- 5个input_sha256均可正确重算。
- 公开规范JSON身份与私有记录、发布清单一致：`46effdb86474a049ba273155e30d7eb430bb889cfee851e0286eff796da51afd`。
- 47项公开值与所附快照的来源哈希、JSON Pointer、原生类型及规范JSON值一致；私有来源映射也一致。
- c001派生JSON行与所附文本快照逐行一致。
- 五个私有案例均为provenance=incomplete、reference=null，可评分数为0。
- TASK.md明确标记为草稿，不进入正式答题。

未直接读取用户Windows原始路径；哈希一致不能单独证明历史真实性、准确观测时间或当时全部可见范围。保留原allowed_root，没有伪造替代路径或重写包来宣称通过原项目加载器。

## 逐题参考建议——尚未批准

| 案例 | 建议分类/确定程度 | 必须限定的范围 |
|---|---|---|
| c001 | runtime / confirmed | 只确认日志直接报告脚本权限错误，不能仅据此确认缺少执行位、属主、挂载策略或具体修复措施。 |
| c002 | geometry / hypothesis | 原记录的相邻图像单原子位移1.2087282854302368 A超过1.2 A保护值；保护触发不证明模型误差原因。 |
| c003 | optimizer / confirmed，仅限明确范围 | 3步预算已用尽且力目标仍未满足。确认的是停止条件，不是Sella有缺陷、势函数不准确或增加步数必然收敛。运行冒烟成功与优化未收敛可以同时成立。 |
| c004 | scf / hypothesis | 多次迭代数达到NELM支持优先审查SCF；没有必要的残差证据，不写成根因已确认。RUN与缺少结束标记不等于任务已失败。 |
| c005 | geometry / hypothesis | 当时阶段的成键区间覆盖保护未通过。仅采用该历史记录的策略，不把它升级成统一科学验收阈值。 |

需要用户确认结构化参考、适用范围及证据集合。本表不是approved记录，不得直接复制后冒充人工批准。

## 正式评分前的三项事项

### 1. 明确evidence_ids究竟考什么

拟议参考列出了每题全部公开证据ID；现有评分器按集合完全相等判分。但当前TASK.md只要求引用本题ID，未要求列出全部ID。因此，c001只引用直接权限报错e003的正确诊断，也可能因未列e001/e002而在联合成绩中失败。

本轮小样本、不改代码的做法：在下一版本公开TASK.md中明确evidence_ids列出全部公开证据ID，并把该部分称为“输入覆盖检查”，而不是“因果相关性/证据筛选质量”。用户批准该答题契约后，再构建新版本正式案例包。不能为了提高成绩临时放宽评分器或修改原始回答。

### 2. 已发布材料不具有私密性

公开仓库中已发布REVIEW_QUEUE.md和含来源、拟议参考的归档。文件名不能提供访问控制。对于能读取此仓库的Agent，这五题应作为公开开发/回归材料，不能作为保密留出题。

进行有限隔离试用时，必须确认答题者不能读仓库、ZIP、审核上下文及其他参考内容。本复审会话已经读过拟议参考，不能充当盲测答题者。仅换目录、开新会话或设只读权限不等于隔离了参考读取。

本轮没有完成对其余启动/审计日志所有潜在敏感内容的逐项审查，也未删除文件、改变仓库访问权限或重写Git历史。

### 3. 区分小样本、仓库审计与科学效果

五个事件属于一个反应组，不是五个独立反应；不能随机拆分关联重试来声称跨反应泛化。

提交报告保留了只读state audit退出1、managed_projection_drift的记录。这与GitHub CI成功及真实计算状态是不同检查。本轮未重跑或修复该审计，未执行状态同步。

## 下一步

先确认五条参考的范围及引用规则；只有实际批准的案例才在新版本创建review.json和reviewed_bundle。保留草稿及历史可见性限制。随后进行独立环境中的首次答题，保存原始回答，由现有确定性评分器评测。

不需要新增框架模块，不从参考生成“正式回答”，不修改科学阈值、不提交HPC计算、不训练模型。

## 固定核对坐标

```text
GitHub compare: b353ba4a00d0ee1d5b3f833dc71d0634f1a1e9cd...f5690e2bfe8eef71df96faf3ba59ad4a5165143e
GitHub Actions run: 36733529458
reports/agent_eval_phase2a/phase2a_20260930_215046_6b0645bc/report.md
reports/agent_eval_phase2a/phase2a_20260930_215046_6b0645bc/REVIEW_QUEUE.md
reports/agent_eval_phase2a/phase2a_20260930_215046_6b0645bc/publication_manifest.json
reports/agent_eval_phase2a/phase2a_20260930_215046_6b0645bc/deliverables.zip
scripts/ts_strategy_engine/learning_evaluation.py
```
