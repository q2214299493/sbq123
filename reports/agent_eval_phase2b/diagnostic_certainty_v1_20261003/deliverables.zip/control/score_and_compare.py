"""Mechanical extraction, one existing-scorer call, and artifact comparison."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parent.parent
C = ROOT / 'control'
BASE = ROOT.parent / 'public_development_smoke_20261002_45a0ff40'
CODE = Path(r'C:\Users\86177\.codex\worktrees\phase1-diagnostic-cases\work')
PUB = Path(r'C:\Users\86177\.codex\worktrees\phase2a-publication\work')
BUNDLE = ROOT.parent / 'sbq_agent_eval/phase2a_20260930_215046_6b0645bc/revision_03_user_approved_20261001/reviewed_bundle'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(path, data):
    with path.open('x', encoding='utf-8', newline='\n') as f:
        f.write(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args]).decode().strip()

assert not (C / 'scoring_started.json').exists()
receipt = json.loads((C / 'execution_receipt.json').read_bytes())
settings = json.loads((C / 'execution_settings.json').read_bytes())
frozen = json.loads((C / 'immutable_materials_before.json').read_bytes())
for name, digest in frozen['files'].items():
    assert sha(Path(name).read_bytes()) == digest, name
assert git(CODE, 'rev-parse', 'HEAD') == frozen['code_head']
assert git(PUB, 'rev-parse', 'HEAD') == frozen['publication_head']
assert not git(CODE, 'status', '--porcelain') and not git(PUB, 'status', '--porcelain')
assert receipt['task_attempt_count'] == 1
baseline_input = (BASE / 'control/submitted_input.txt').read_bytes()
assert (C / 'submitted_input.txt').read_bytes() == (ROOT / 'harness/diagnostic_certainty_v1.txt').read_bytes() + b'\n' + baseline_input
events = []
malformed = []
for i, line in enumerate((C / 'first_events.jsonl').read_bytes().splitlines(), 1):
    try:
        events.append(json.loads(line))
    except (ValueError, UnicodeError):
        malformed.append(i)
items = [e['item'] for e in events if isinstance(e.get('item'), dict)]
tool_items = [i for i in items if i.get('type') not in {'agent_message', 'reasoning', 'error', 'plan', 'todo_list'}]
audit = {'status': 'NO_EXPLICIT_CONTAMINATION_OBSERVED' if not tool_items else 'EXTRA_ACTIVITY_REQUIRES_REVIEW', 'explicit_reference_read_observed': False, 'overall_contamination_status': 'unknown', 'observed_extra_activity': tool_items, 'visible_item_types': [i.get('type') for i in items], 'visible_jsonl_records': len(events), 'malformed_lines': malformed, 'hidden_context_injection': 'unknown', 'reference_access_isolation_verified': False, 'all_tools_disabled_verified': False, 'limitation': 'CLI-visible events only; absence of an observed read does not establish technical impossibility.'}
write(C / 'visible_activity_audit.json', audit)
assert not tool_items, 'Unexpected activity: preserve original response and review before scoring'
raw = (C / 'first_raw_answer.txt').read_bytes()
payload = raw.strip()
method = 'whole_json'
if payload.startswith(b'```'):
    lines = payload.splitlines(keepends=True)
    assert lines[0].strip() in {b'```json', b'```'} and lines[-1].strip() == b'```'
    payload = b''.join(lines[1:-1]).strip()
    method = 'single_json_fence'
json.loads(payload)
scoring_bytes = raw if method == 'whole_json' else payload
with (C / 'answers.json').open('xb') as f:
    f.write(scoring_bytes)
write(C / 'extraction_record.json', {'method': method, 'raw_byte_sha256': sha(raw), 'scoring_input_byte_sha256': sha(scoring_bytes), 'same_bytes': raw == scoring_bytes, 'diagnostic_fields_or_ids_modified': False, 'missing_answers_completed': False, 'answer_regenerations': 0})
cmd = [r'C:\Anaconda\python.exe', '-X', 'utf8', '-B', '-m', 'scripts.ts_strategy_engine.cli', 'learning', 'cases-evaluate', '--bundle', str(BUNDLE), '--answers', str(C / 'answers.json'), '--report', str(C / 'score_report.json')]
write(C / 'scoring_started.json', {'command': cmd, 'cwd': str(CODE), 'scoring_attempt_count': 1})
score_run = subprocess.run(cmd, cwd=CODE, capture_output=True)
(C / 'scorer_stdout.txt').write_bytes(score_run.stdout)
(C / 'scorer_stderr.txt').write_bytes(score_run.stderr)
write(C / 'scoring_execution.json', {'command': cmd, 'cwd': str(CODE), 'exit_code': score_run.returncode, 'scoring_attempt_count': 1})
assert (C / 'score_report.json').exists(), 'Scorer produced no report; retained failure receipt'
score = json.loads((C / 'score_report.json').read_bytes())
baseline = json.loads((BASE / 'control/score_report.json').read_bytes())
for field in ['public_sha256', 'private_sha256', 'policy_sha256', 'builder_sha256', 'evaluator_sha256', 'evaluation_code_sha256']:
    assert score[field] == baseline[field], field
bmap = {c['case_id']: c for c in baseline['cases']}
cmap = {c['case_id']: c for c in score['cases']}
old_matches = {k for k, c in bmap.items() if c['status'] == 'match'}
new_matches = {k for k, c in cmap.items() if c['status'] == 'match'}
gained = sorted(new_matches - old_matches)
lost = sorted(old_matches - new_matches)
category = 'MIXED' if gained and lost else 'REGRESSION' if lost else 'IMPROVED_NO_REGRESSION' if gained else 'NO_CHANGE'
rows = [{'case_id': k, 'baseline_status': bmap[k]['status'], 'candidate_status': cmap[k]['status'], 'original_match_preserved': k in new_matches if k in old_matches else None} for k in bmap]
config = json.loads((C / 'configuration_check.json').read_bytes())
conclusion = 'candidate improved performance on this public development set' if category == 'IMPROVED_NO_REGRESSION' else category
report = {
    'evaluation_mode': 'public_development_smoke', 'reference_access_isolation_verified': False, 'capability_improvement_established': False,
    'baseline_result_commit': frozen['publication_head'], 'baseline_branch': 'codex/phase2a-diagnostic-trial-20260930', 'code_commit': frozen['code_head'],
    'public_sha256': score['public_sha256'], 'harness_id': 'diagnostic_certainty_v1', 'harness_sha256': sha((ROOT / 'harness/diagnostic_certainty_v1.txt').read_bytes()),
    'completed_at': datetime.now(timezone(timedelta(hours=8))).isoformat(), 'comparison_category': category, 'conclusion': conclusion,
    'baseline_counts': baseline['counts'], 'candidate_counts': score['counts'], 'case_results': rows, 'gained_matches': gained, 'lost_matches': lost,
    'execution_model_setting': settings['requested_model'], 'backend_model_identifier': 'unknown: not present in CLI-visible events',
    'baseline_cli_version': config['baseline_cli_version'], 'candidate_cli_version': config['candidate_cli_version'], 'cli_version_changed': config['cli_version_changed'],
    'reasoning_effort_setting': 'high', 'service_tier_setting': 'default', 'elapsed_seconds': receipt['elapsed_seconds'], 'cli_exit_code': receipt['exit_code'], 'scorer_exit_code': score_run.returncode,
    'candidate_answer_task_attempts': 1, 'candidate_scoring_attempts': 1, 'answer_regenerations': 0, 'underlying_model_request_count': 'unknown',
    'actual_thread_ids': [e.get('thread_id') for e in events if e.get('type') == 'thread.started'],
    'reported_turn_usage': [e.get('usage') for e in events if e.get('type') == 'turn.completed'],
    'visible_activity_audit': audit, 'execution_receipt': receipt,
    'scorer_integrity_ok': score['integrity_ok'], 'scorer_comparison_ready': score['comparison_ready'], 'scorer_comparison_ready_implies_reference_isolation': False,
    'checks': {'only_harness_prefix_added_to_baseline_input': True, 'benchmark_and_baseline_files_unchanged': len(frozen['files']), 'scorer_and_policy_identity_unchanged': True, 'both_worktrees_clean_and_unchanged': True, 'raw_scoring_bytes_identical': raw == scoring_bytes},
    'not_verified': ['strict reference isolation', 'hidden backend context', 'actual backend model snapshot', 'underlying model request count', 'causal attribution to harness alone given CLI version change and single trials', 'generalization', 'production improvement'],
    'not_run': ['second candidate or answer attempt', 'baseline rerun', 'second scoring attempt', 'production changes', 'source/reference/benchmark edits', 'repo-state sync', 'commit/push/merge', 'scientific calculations/training', 'production database access'],
}
for name, digest in frozen['files'].items():
    assert sha(Path(name).read_bytes()) == digest, name
assert not git(CODE, 'status', '--porcelain') and not git(PUB, 'status', '--porcelain')
write(ROOT / 'comparison_report.json', report)
table = '\n'.join(f"| {r['case_id']} | {r['baseline_status']} | {r['candidate_status']} |" for r in rows)
md = f'''# Phase 2B：单一 Diagnostic Harness 候选实验

结果分类：**{category}**。基线 {baseline['counts']['matched']}/{baseline['counts']['scorable']}；候选 {score['counts']['matched']}/{score['counts']['scorable']}。新增匹配：{', '.join(gained) or '无'}；旧匹配退步：{', '.join(lost) or '无'}。

{conclusion}

| 案例 | Baseline | Candidate |
|---|---|---|
{table}

## 固定输入与唯一改动

- 基线分支：`codex/phase2a-diagnostic-trial-20260930`；结果提交：`{frozen['publication_head']}`。
- public_sha256：`{score['public_sha256']}`。
- Harness v1：[原始文本](harness/diagnostic_certainty_v1.txt)，SHA-256：`{report['harness_sha256']}`。
- 实际输入精确等于 Harness 原字节 + 一个换行 + 基线完整公开输入原字节。三个公开文件及 47 份基线/参考材料哈希保持不变，评分器与 policy 身份相同。

## 一次执行与评分

CLI 模型设置 `gpt-6.1-sol`；reasoning effort `high`；service tier `default`。复用同一单次流程、输出格式及工具关闭参数。CLI 从 `{config['baseline_cli_version']}` 变为 `{config['candidate_cli_version']}`，没有安装或降级；这是真实环境差异，不能将结果变化归因于 Harness 单一因素。

候选仅执行 1 次答题、1 次现有 `cases-evaluate` 评分；耗时 {receipt['elapsed_seconds']} 秒，CLI 退出码 {receipt['exit_code']}，scorer 退出码 {score_run.returncode}。无答案修复或再生成；本轮原始回答与评分输入字节一致：{raw == scoring_bytes}。底层模型请求次数及实际后端模型标识未知。

保留[首次原始回答](control/first_raw_answer.txt)、[完整 CLI 可见事件](control/first_events.jsonl)、[完整实际输入](control/submitted_input.txt)、[执行设置](control/execution_settings.json)、[执行回执](control/execution_receipt.json)、[机械提取记录](control/extraction_record.json)、[实际评分报告](control/score_report.json)、[评分命令和退出码](control/scoring_execution.json)及[详细对照报告](comparison_report.json)。启动警告原样保留；未为消除警告重试。

可见事件未发现额外工具活动；参考读取与隐含上下文的完整隔离尚未验证，整体污染状态为未知。没有将未观察到的行为写成技术上不可能发生。scorer comparison_ready={score['comparison_ready']} 仅表示评分比较条件满足。

## 核验与边界

准备及执行脚本语法检查通过；使用现有 owning Python sha256_json 校验 public 身份；两处代码工作树及 HEAD 保持不变；运行前后输入、批准参考与基线材料身份一致。本次只读仓库审计退出码 1，保留既有模块投影漂移（[审计](control/repository_audit.json)、[命令](control/audit_execution.json)），未修复、未 sync。没有源码变更，因此未运行生产回归测试。

evaluation_mode = public_development_smoke

reference_access_isolation_verified = false

capability_improvement_established = false

规则依据这五题的开发结果提出，本轮不证明能力提升、泛化、幻觉解决或生产 Agent 改善。未修改 benchmark、参考、评分器、科学标准或生产系统；未计算、训练、访问生产数据库或提交推送合并。Harness v1 保持冻结，等待下一步审核。
'''
with (ROOT / 'comparison_report.md').open('x', encoding='utf-8', newline='\n') as f:
    f.write(md)
files = {}
for p in sorted(ROOT.rglob('*')):
    if p.is_file() and 'cli_runtime_state' not in p.parts:
        files[p.relative_to(ROOT).as_posix()] = {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
write(ROOT / 'artifact_manifest.json', {'files': files, 'excluded': 'control/cli_runtime_state: CLI internal scratch state; no credentials or private reference copies are delivered.'})
print(json.dumps({'comparison_category': category, 'baseline_counts': baseline['counts'], 'candidate_counts': score['counts'], 'case_results': rows, 'elapsed_seconds': receipt['elapsed_seconds'], 'cli_exit_code': receipt['exit_code'], 'scorer_exit_code': score_run.returncode, 'report': str(ROOT / 'comparison_report.md')}, ensure_ascii=False))
