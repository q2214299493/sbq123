from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib, json, os, shutil, subprocess, sys
OUT = Path(__file__).resolve().parent
CTX = json.loads((OUT / "launch_context.json").read_text(encoding="utf-8"))
CODE, EVIDENCE = Path(CTX["code_root"]), Path(CTX["evidence_root"])
sys.path.insert(0, str(CODE))
from scripts.artifact_io import sha256_file, sha256_json
from scripts.ts_strategy_engine.learning_evaluation import _load_bundle
from scripts.ts_strategy_engine.strategy_learning import policy
ENV = dict(os.environ, GIT_OPTIONAL_LOCKS="0", PYTHONDONTWRITEBYTECODE="1")
NOW = datetime.now(timezone(timedelta(hours=8))).isoformat()
commands, source_records, candidates = [], [], []
def write(name, value, binary=False):
    p = OUT / name
    with p.open("xb" if binary else "x", **({} if binary else {"encoding":"utf-8", "newline":"\n"})) as f:
        f.write(value if binary or isinstance(value,str) else json.dumps(value,ensure_ascii=False,indent=2)+"\n")
def run(args):
    r = subprocess.run(args,cwd=CODE,env=ENV,capture_output=True,text=True,encoding="utf-8",errors="replace")
    commands.append({"argv":args,"cwd":str(CODE),"exit_code":r.returncode,"stdout":r.stdout,"stderr":r.stderr})
    return r
# Capture the required read-only audit; it does not establish scientific validity.
audit = run([sys.executable,"-B","-m","scripts.state_manager","--root",str(CODE),"audit","--phase","start","--format","json"])
write("repository_audit.json",json.loads(audit.stdout) if audit.stdout.strip().startswith("{") else {"stdout":audit.stdout,"stderr":audit.stderr,"exit_code":audit.returncode})
SNAP = OUT / "snapshots"
SNAP.mkdir()
base = "calculations/fe110_c2ho_h_to_c2h2o_ts_20260822/"
def source(case_id, number, relative, text=False):
    p=(EVIDENCE/relative).resolve(strict=True)
    if not p.is_relative_to(EVIDENCE): raise RuntimeError("Source outside evidence root")
    before=sha256_file(p); data=p.read_bytes()
    if hashlib.sha256(data).hexdigest()!=before or sha256_file(p)!=before:
        raise RuntimeError(f"Changing source, case paused: {p}")
    stem=f"{case_id}_s{number:02d}"
    if text:
        original=SNAP/(stem+".txt")
        with original.open("xb") as f: f.write(data)
        obj={"lines":data.decode("utf-8-sig").splitlines()}
        target=SNAP/(stem+".json")
        with target.open("x",encoding="utf-8",newline="\n") as f: json.dump(obj,f,ensure_ascii=False,indent=2); f.write("\n")
        kind="derived_json_from_exact_utf8_text_lines"
    else:
        obj=json.loads(data.decode("utf-8-sig"))
        target=SNAP/(stem+".json")
        with target.open("xb") as f: f.write(data)
        original=target; kind="original_json_byte_copy"
    rec={"case_id":case_id,"original_path":str(p),"original_sha256":before,"original_bytes":len(data),
         "snapshot_path":str(target),"snapshot_sha256":sha256_file(target),"identity":kind,
         "original_copy":str(original),"created_at":NOW,"selected_observations":[]}
    source_records.append(rec)
    return target,obj,rec
def select(src, pointers):
    target,obj,rec=src; items=[]
    for pointer in pointers:
        value=obj
        for token in pointer[1:].split("/"):
            value=value[int(token)] if isinstance(value,list) else value[token]
        if isinstance(value,(dict,list)): raise RuntimeError("Expected native scalar")
        eid=f"e{sum(len(c['public_evidence']) for c in candidates)+len(items)+1:03d}"
        item={"evidence_id":eid,"path":target.name,"sha256":sha256_file(target),"pointer":pointer,"value":value}
        items.append(item)
        provenance={"evidence_id":eid,"pointer":pointer,"native_type":type(value).__name__,"value":value}
        if rec["identity"].startswith("derived"): provenance["original_text_lines_1based"]=[int(pointer.split("/")[-1])+1]*2
        else: provenance["original_json_pointer"]=pointer
        rec["selected_observations"].append(provenance)
    return items
def add(cid,question,observations,label,status,summary,basis,visibility,confirm):
    candidates.append({"case_id":cid,"group_id":"g001","question":question,"provenance":"incomplete",
                       "public_evidence":observations,"reference":None})
    return {"case_id":cid,"group_id":"g001","event_summary":summary,"inclusion":"draft_only",
            "visibility":visibility,"review_basis":basis,"needs_confirmation":confirm,
            "review_status":"pending","existing_approval":None,
            "proposed_reference":{"failure_class":label,"root_cause_status":status,
             "next_review":policy()["failure_routes"][label],"evidence_ids":[x["evidence_id"] for x in observations]}}
queue=[]
s=source("c001",1,base+"gpu_dual_model_complete_path_rebuild_v10_nonabsolute_guards_20260829/remote_failure_return/production-1347.out",True)
queue.append(add("c001","这是一次路径计算的原始进程输出。依据可见输出选择失败分类、根因确定程度与下一步审查路线；不要推断未出现的模型或科学结果。",select(s,["/lines/0","/lines/1","/lines/4"]),"runtime","confirmed",
 "GPU1347：已选择 GPU，运行包装脚本报权限不足。",
 "LEARNING.md 历史导入和 historical_gpu_1347_request.json 是后续审查线索，未批准此新题/引用集合；具体缺少执行位的解释不进入公开输入。",
 "partially_verified：原始运行日志；无内嵌时间戳，确切历史可见时刻待核实。",
 "确认运行日志当时可见性、runtime/confirmed 是否仅指执行权限故障，以及精确 evidence_ids；不能从日志单独确认文件执行位。"))
s=source("c002",1,base+"gpu_oh_complete_path_epoch6_20260902/returned_job1508/ordinary_ml_neb.geometry_guard_failure.json")
queue.append(add("c002","这是普通 ML-NEB 的终止检查点；距离字段单位为 A。依据该检查点选择失败分类、根因确定程度与审查路线，区分直接观测与尚未证实的原因。",select(s,[
 "/stage","/stage_steps","/geometry_guards/maximum_single_movable_atom_step_A",
 "/geometry_guards/maximum_single_movable_atom_step_limit_A","/geometry_guards/maximum_single_movable_atom_step_passed",
 "/geometry_guards/maximum_adjacent_rmsd_A","/geometry_guards/adjacent_rmsd_passed",
 "/geometry_guards/minimum_pair_distance_passed","/geometry_guards/periodic_branch_numeric_passed"]),"geometry","hypothesis",
 "GPU1508：268 步检查点，单原子相邻图像位移 1.2087 A 超过当时 1.2 A 保护值。",
 "failure_review_job1508.json 与历史导入是后续解释；原始 guard 数值入题，model_error_proven 和后续路由排除。",
 "partially_verified：生产者失败保护记录；后续 review 明确引用其哈希；独立可见性/时间仍待审核。",
 "确认公开上下文充分、geometry/hypothesis 与引用集合；观测到保护触发不证明模型误差。"))
s1=source("c003",1,"outputs/matris_sella_smoke_20260905/returned/results/job_1509/smoke_result.json")
s2=source("c003",2,"outputs/matris_sella_smoke_20260905/returned/results/job_1509/sella/candidate_manifest.json")
# Reserve IDs across two sources in one case without synthesizing observations.
first=select(s1,["/optimizer_steps","/model_evaluations","/initial_fmax_eV_per_A","/last_fmax_eV_per_A","/error"])
second=select(s2,["/settings/max_steps","/settings/fmax_eV_per_A","/snapshots/3/geometry_passed"])
offset=len(first)
for j,item in enumerate(second):
    old=item["evidence_id"]; item["evidence_id"]=f"e{sum(len(c['public_evidence']) for c in candidates)+offset+j+1:03d}"
    s2[2]["selected_observations"][j]["evidence_id"]=item["evidence_id"]
queue.append(add("c003","这次 Sella 试用有显式步数预算；力单位为 eV/A。依据设置和结束时观测，判断优化阶段为何尚未达到目标并选择诊断分类与审查路线。该问题不评价整体运行冒烟测试的成功与否。",first+second,"optimizer","confirmed",
 "GPU1509：真实受控试用，预算 3 步，末力 1.2851 eV/A 大于目标 0.05 eV/A；不是合成测试。",
 "work_review.json 和 return_manifest.json 仅用于来源/范围核对；真实运行完成不等于优化收敛。新的标签与 evidence_ids 未经人工批准。",
 "partially_verified：结束时的生产者结果与候选设置；原始退出记录有时间，未证实独立答题者的历史读取范围。",
 "确认将有意限定预算的未收敛阶段归为 optimizer/confirmed 的表述范围；若不符合题型则排除此题，不能强制标成整体运行失败。"))
s=source("c004",1,base+"dimer_job9745217_image02_20260907/checkpoint_20260908_1103.json")
queue.append(add("c004","这是一次运行中的 Dimer 检查点，VASP 力评估包含旋转/位移，不等同于 Dimer 平移步。SCF 迭代为计数，最新完整原子力和目标的单位为 eV/A。依据当前材料给出诊断类别、确定程度和审查路线；缺失依据应保持未知。",select(s,[
 "/observed_at","/scheduler_status","/completed_vasp_evaluations","/nelm",
 "/completed_evaluation_scf_iterations/0","/completed_evaluation_scf_iterations/7",
 "/completed_evaluation_scf_iterations/8","/completed_evaluation_scf_iterations/9",
 "/latest_complete_outcar_max_atomic_force_eVA","/force_target_eVA",
 "/normal_termination_marker_present","/required_accuracy_marker_present"]),"scf","hypothesis",
 "Dimer9746548：10 个完成的力评估中四项达到 NELM=200；仍 RUN，无正常结束/精度标记。",
 "原始时间标记检查点和当前任务文档一致；未选后续分析/接受结论。本轮未重新读取 OUTCAR 残差，不能把达到 NELM 直接当作最终 SCF 根因已确认。",
 "partially_verified：检查点自报 observed_at=2026-09-08T11:03:28+08:00；原始监测完整性/当时读取范围未独立复核。",
 "确认需要 scf/hypothesis 还是 unknown；审核 SCF 残差/EDIFF 是否足够，并确认引用集合。"))
s=source("c005",1,base+"gpu_dual_model_staged_release_v4_20260826/gpu_return_job1324/production/restraint_release_01_half_strength.geometry_guard_failure.json")
queue.append(add("c005","这是 ML 路径逐步释放临时约束时的检查点；距离单位为 A，弹簧系数为 eV/A^2。依据当时保护设置及观测选择诊断分类、确定程度和下一步审查路线，不推断尚无观测的模型误差。",select(s,[
 "/stage","/stage_steps","/geometry_guards/monitored_bonds/0/name",
 "/geometry_guards/monitored_bonds/0/important_interval_A/0","/geometry_guards/monitored_bonds/0/important_interval_A/1",
 "/geometry_guards/monitored_bonds/0/covered_internal_images/0","/geometry_guards/monitored_bonds/0/covered_internal_images/1",
 "/geometry_guards/monitored_bonds/0/minimum_internal_images","/geometry_guards/monitored_bonds/0/maximum_observed_backtrack_A",
 "/geometry_guards/maximum_single_movable_atom_step_A","/geometry_guards/maximum_single_movable_atom_step_limit_A",
 "/geometry_guards/periodic_branch_numeric_passed","/monitored_guard_policy/require_monitored_bond_interval_coverage",
 "/monitored_guard_policy/bond_spring_constant_eV_per_A2"]),"geometry","hypothesis",
 "GPU1324：半强度释放第 1 步，仅图像10/11覆盖当时要求的 O-H 区间，要求至少3个。",
 "docs/04_ERROR_LOG.md E-018 为后续解释；只公开原始阶段数值和当时配置，不导出历史结论或建议。",
 "partially_verified：原始生产者阶段 guard；未用文件 mtime 代替观测时间。",
 "确认阶段可见性、coverage/geometry 归类、与其他重试的分组，以及精确引用集合。"))
write("snapshots/manifest.json",{"schema_version":1,"cases":candidates})
intake={"status":"AWAITING_REFERENCE_REVIEW","created_at":NOW,"candidate_events_reviewed":len(queue),
 "included_draft_cases":len(candidates),"scorable_cases":0,"reaction_groups":1,
 "group_mapping":{"g001":{"reaction":"C2HO* + H* -> C2H2O* on Fe(110)","grouping_basis":"Conservative shared overall reaction group; distinct subpaths, retries and smoke observations are not independent reactions."}},
 "candidates":queue,"sources":source_records,"excluded_candidates":[],
 "limitations":["No independently verified human approval covers these new structured expected values and exact evidence-ID sets.",
 "Historical visibility is partially verified only; file mtime was not used as an observation timestamp.",
 "No fabricated unknown case, synthetic perturbation, answers or score was produced."]}
write("intake.json",intake)
rows=["# 私有参考审核队列\n\n不得交给答题者。拟议 reference 只存在本表和 intake，不进入评分输入。\n",
 "| case_id | group_id | 材料定位 | 公开输入摘要 | 可见性 | 拟议诊断 | 审核依据 | 尚需确认 | 状态 |",
 "|---|---|---|---|---|---|---|---|---|"]
for row in queue:
    sources=[x["original_path"] for x in source_records if x["case_id"]==row["case_id"]]
    p=row["proposed_reference"]
    cells=[row["case_id"],row["group_id"],"; ".join(sources),row["event_summary"],row["visibility"],
           json.dumps(p,ensure_ascii=False),row["review_basis"],row["needs_confirmation"],"pending"]
    rows.append("| "+" | ".join(x.replace("|","\\|").replace("\n"," ") for x in cells)+" |")
write("REVIEW_QUEUE.md","\n".join(rows)+"\n")
build=run([sys.executable,"-B","-m","scripts.ts_strategy_engine.cli","learning","cases-build",
 "--manifest",str(SNAP/"manifest.json"),"--allowed-root",str(SNAP),"--bundle",str(OUT/"draft_bundle")])
if build.returncode:
    write("execution_log.json",commands)
    raise RuntimeError(f"Build failed; partial output preserved: {build.stderr}")
marker,public,private=_load_bundle(OUT/"draft_bundle")
if any(c["reference"] is not None or c["provenance"]!="incomplete" for c in private["cases"]):
    raise RuntimeError("Unexpected scored reference")
PACK=OUT/"answer_pack"; PACK.mkdir()
with (PACK/"public.json").open("xb") as f: f.write((OUT/"draft_bundle/public.json").read_bytes())
labels={"schema_version":1,"failure_routes":policy()["failure_routes"],"root_cause_status":sorted(__import__("scripts.ts_strategy_engine.learning_cases",fromlist=["ROOT_STATUSES"]).ROOT_STATUSES),
 "answer_set_keys":["schema_version","public_sha256","answers"],"answer_item_keys":["case_id","input_sha256","failure_class","root_cause_status","next_review","evidence_ids"]}
write("answer_pack/FORMAT.json",labels)
task="""# 草稿诊断输入 — 不进入正式答题\n\n本包仅用于公开输入审查。参考尚未批准；不得宣称基线成绩。\n\n仅依据 public.json 的各题证据提出结构化诊断。允许标签和对应路线见 FORMAT.json；next_review 必须与所选 failure_class 对应。保持类型和值原样；引用证据使用该题 evidence_id。不要运行计算、训练或改变科学接受标准。\n\n后续经人工批准并创建新版本后，由只挂载冻结公开包的独立环境答题；读取边界尚未验证，本包目录分离不构成隔离。整理会话不能充当正式答题者。\n\n回答文件顶层包含 schema_version: 1、public_sha256 和 answers 数组；各项包含 case_id、input_sha256、failure_class、root_cause_status、next_review、evidence_ids。两种哈希是现有规范 JSON 哈希，不能用文件字节哈希替代。复制 public.json 中 input_sha256，不重新改写输入。\n\npublic_sha256: """+marker["public_sha256"]+"\n"
write("answer_pack/TASK.md",task)
# Inspect actual artifacts with the existing loader, plus original-source stability.
checks={"loader_validated_cases":len(public["cases"]),"scorable_cases":sum(c["reference"] is not None for c in private["cases"]),
 "public_sha256":marker["public_sha256"],"answer_pack_files":sorted(p.name for p in PACK.iterdir()),
 "answer_pack_public_byte_equal":(PACK/"public.json").read_bytes()==(OUT/"draft_bundle/public.json").read_bytes(),
 "source_unchanged":{r["original_path"]:sha256_file(Path(r["original_path"]))==r["original_sha256"] for r in source_records},
 "scalar_count":sum(len(c["evidence"]) for c in public["cases"]),"semantic_leakage_independently_verified":False,
 "isolation_verified":False,"model_answer_generated":False,"evaluation_executed":False}
if not all(checks["source_unchanged"].values()): raise RuntimeError("Source changed after extraction")
write("artifact_checks.json",checks)
write("execution_log.json",commands)
print(json.dumps({"output_root":str(OUT),"status":intake["status"],"cases":len(candidates),"groups":1,"scorable":0,
                 "public_sha256":marker["public_sha256"],"scalar_count":checks["scalar_count"],"audit_exit_code":audit.returncode},ensure_ascii=False))
