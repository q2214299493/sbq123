# 草稿诊断输入 — 不进入正式答题

本包仅用于公开输入审查。参考尚未批准；不得宣称基线成绩。

仅依据 public.json 的各题证据提出结构化诊断。允许标签和对应路线见 FORMAT.json；next_review 必须与所选 failure_class 对应。保持类型和值原样；引用证据使用该题 evidence_id。不要运行计算、训练或改变科学接受标准。

后续经人工批准并创建新版本后，由只挂载冻结公开包的独立环境答题；读取边界尚未验证，本包目录分离不构成隔离。整理会话不能充当正式答题者。

回答文件顶层包含 schema_version: 1、public_sha256 和 answers 数组；各项包含 case_id、input_sha256、failure_class、root_cause_status、next_review、evidence_ids。两种哈希是现有规范 JSON 哈希，不能用文件字节哈希替代。复制 public.json 中 input_sha256，不重新改写输入。

public_sha256: 65b89a7df4d2105f0a084fb595d6425c7d0e7343b21d13edbe81365231c3d571
