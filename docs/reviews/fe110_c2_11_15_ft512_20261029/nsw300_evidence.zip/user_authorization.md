# User instruction,2026-10-29

> 调整为300 把

Scope:these15already-submitted11-15adsorption tasks only;NSW80→300,all other physical settings unchanged.
Necessary implementation:hold13PEND jobs while amending their input bytes;retain job IDs.
Two RUN jobs11_A/11_B cannot adopt a new NSW at runtime:request graceful STOPCAR LSTOP,
retain all original outputs and continue from reviewed final CONTCAR in new gated directories.
No force termination,unrelated job changes,model inference or training.
